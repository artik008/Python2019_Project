# Python2019_Project

Project for python prak by Timur Bikbulatov and Artem Shitik

Link to [documentation](https://htmlpreview.github.io/?https://raw.githubusercontent.com/artik008/Python2019_Project/add-docs/docs/_build/html/index.html)(documentation)


![Example](./images/tanks.gif)
