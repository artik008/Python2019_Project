name = "Python2019_Project"

from .tanki import *
